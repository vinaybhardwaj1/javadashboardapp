package com.j2io.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;




import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.hibernate.Session;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
//import org.springframework.web.portlet.mvc.SimpleFormController;
import org.springframework.web.servlet.ModelAndView;

import com.j2io.entity.Category;
import com.j2io.entity.DealMaster;
import com.j2io.entity.DealReport;
import com.j2io.entity.KeyParameter;
import com.j2io.services.CategoryServiceImpl;
import com.j2io.services.CategoryFacade;
import com.j2io.services.DealServiceImpl;



@Controller
@RequestMapping(value="/self_assessment.htm")
public class SelfAssessmentController {
	
	@ModelAttribute("dealList")
	public List<String> populateDeal(){
		List<String> dealList = new ArrayList<String>();
		DealServiceImpl dealService = new DealServiceImpl();
		dealList = dealService.getAllDealNames();
		return dealList;
	}
	
	@ModelAttribute("deal")
	public DealMaster populateDeal(HttpServletRequest request,@ModelAttribute("deal") DealMaster deal){
		DealServiceImpl dealService= new DealServiceImpl();
		if(deal.getDealId() == 0){
			  deal=dealService.getDealByNameAndDate(request.getParameter("selectedDeal"),request.getParameter("month"));
		  }else{
				deal = dealService.getDealByNameAndDate(deal.getDealName(),deal.getMonth());
		  }
		return deal;
	}
	

	
	@ModelAttribute("score")
	public Map< Integer, String > populateScore(){
		Map< Integer, String > score = new HashMap<Integer, String>();
		score.put(1, "Yes");
		score.put(2, "NA");
		score.put(0, "No");
		return score;
	}
	
	  @RequestMapping(method = RequestMethod.GET)
	  public ModelAndView setupForm(HttpServletRequest request) {
		  DealMaster deal = new DealMaster();
		  DealServiceImpl dealService= new DealServiceImpl();
		  if(request.getParameter("selectedDeal")!=null){
			  deal=dealService.getDealByNameAndDate(request.getParameter("selectedDeal"),request.getParameter("month"));
		  }else{
				deal = dealService.getDealByNameAndDate("L\'Oreal","January");
		  }
		  DealReport dealReport = new DealReport();
 			ModelAndView mv = new ModelAndView("self_assessment.jsp", "deal", deal);
 			
 			if(deal == null){
 				ModelAndView mv1 = new ModelAndView("self_assessment.jsp", "deal", new DealMaster());
 				
 				mv1.addObject("noDeal",1);
 				mv1.addObject("fScore", 999);
 				return mv1;
 			}
 			mv.addObject("noDeal",0);
 			
 			dealReport = dealService.getDealReportByDealId(deal.getDealId());
 			
			if(dealReport == null){
				mv.addObject("fScore", 999);
			}else{
				mv.addObject("fScore", dealReport.getFounScore());
				mv.addObject("tScore", dealReport.getTranScore());
				mv.addObject("sScore", dealReport.getStabScore());
				mv.addObject("iScore", dealReport.getInnoScore());
				mv.addObject("totalScore", dealReport.getTotalScore());
			}
 			
		  return mv;
	    }

	
	@RequestMapping(method=RequestMethod.POST)
	public ModelAndView calculateReport(HttpServletRequest request,
            @ModelAttribute("deal") DealMaster deal,
            BindingResult bindResult) throws Exception {
		
		System.out.println("In Post");
		if (bindResult.hasErrors()) {
			System.out.println(bindResult);
		}
		
		DealServiceImpl dealService= new DealServiceImpl();
		DealReport dealReport = new DealReport();
		DealReport dealReportNew = new DealReport();
		
		
		if(request.getParameter("saveProgress")!=null){
			ModelAndView mv = new ModelAndView("self_assessment.jsp", "deal", deal);
			dealService.saveDealService(deal);
			dealReport = dealService.getDealReportByDealId(deal.getDealId());
			if(dealReport != null){
				dealService.deleteDealReportByDealId(deal.getDealId());
			}
			
			mv.addObject("fScore", 999);
			mv.addObject("noDeal", 0);
			return mv;
		}
		
		if(request.getParameter("calculate")!=null){
			dealReportNew = dealService.calculateDealService(deal);
			dealService.saveDealService(deal);
			
			dealReport = dealService.getDealReportByDealId(deal.getDealId());
			if(dealReport != null){
				dealService.deleteDealReportByDealId(deal.getDealId());
			}
			
			ModelAndView mv = new ModelAndView("self_assessment.jsp", "deal", deal);
			mv.addObject("fScore", dealReportNew.getFounScore());
			mv.addObject("tScore", dealReportNew.getTranScore());
			mv.addObject("sScore", dealReportNew.getStabScore());
			mv.addObject("iScore", dealReportNew.getInnoScore());
			mv.addObject("totalScore", dealReportNew.getTotalScore());
			mv.addObject("noDeal", 0);
		  return mv;
			}
		if(request.getParameter("saveReport")!=null){
			
			dealReport = dealService.getDealReportByDealId(deal.getDealId());			
			dealService.saveDealService(deal);
			dealReportNew = dealService.calculateDealService(deal);
			if(dealReport != null){
			dealReport.setFounScore(dealReportNew.getFounScore());
			dealReport.setTranScore(dealReportNew.getTranScore());
			dealReport.setStabScore(dealReportNew.getStabScore());
			dealReport.setInnoScore(dealReportNew.getInnoScore());
			dealReport.setTotalScore(dealReportNew.getTotalScore());
			dealService.saveDealReport(dealReport);
			}else{
				dealService.saveDealReport(dealReportNew);
			}
			ModelAndView mv = new ModelAndView("self_assessment.jsp", "deal", deal);

			
			mv.addObject("fScore", dealReportNew.getFounScore());
			mv.addObject("tScore", dealReportNew.getTranScore());
			mv.addObject("sScore", dealReportNew.getStabScore());
			mv.addObject("iScore", dealReportNew.getInnoScore());
			mv.addObject("totalScore", dealReportNew.getTotalScore());
			mv.addObject("noDeal", 0);
			return mv;
		}
		else{
			ModelAndView mv = new ModelAndView("self_assessment.jsp", "deal", deal);
			mv.addObject("noDeal", 0);
			return mv;
		}
	}



}

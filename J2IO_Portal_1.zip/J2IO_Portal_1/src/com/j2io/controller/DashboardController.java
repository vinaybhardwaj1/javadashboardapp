package com.j2io.controller;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.j2io.dao.DealDao;
import com.j2io.entity.DealMaster;
import com.j2io.entity.DealReport;
import com.j2io.services.DealServiceImpl;

@Controller
@RequestMapping(value="/dashboard.htm")
public class DashboardController {
	
	@ModelAttribute("duLeadList")
	public List<String> populateDuLead(){
		List<String> duLeadList = new ArrayList<String>();
		DealServiceImpl dealService = new DealServiceImpl();
		duLeadList = dealService.getAllDuLeadNames();
		return duLeadList;
	}
	
	@ModelAttribute("dgLeadList")
	public List<String> populateDgLead(){
		List<String> dgLeadList = new ArrayList<String>();
		DealServiceImpl dealService = new DealServiceImpl();
		dgLeadList = dealService.getAllDgLeadNames();
		return dgLeadList;
	}
	
	@ModelAttribute("locationList")
	public List<String> populateLocation(){
		List<String> locationList = new ArrayList<String>();
		DealServiceImpl dealService = new DealServiceImpl();
		locationList = dealService.getAllLocations();
		return locationList;
	}
	
	@RequestMapping(method = RequestMethod.GET)
	public ModelAndView setupDashboard() {
		List<DealMaster> deals = new ArrayList<DealMaster>();
		List<DealReport> dealReports = new ArrayList<DealReport>();
		Map<DealMaster , DealReport> map = new HashMap<DealMaster, DealReport>();
		DealDao dao = new DealDao();
		ModelAndView mv = new ModelAndView("dashboard.jsp");
		deals = dao.getDashboardData("January", "All", "All", "All");
		dealReports = dao.getDashboardReportData(deals);
		DealMaster deal = new DealMaster();
		DealReport dealReport = new DealReport();
		for(int i = 0; i<deals.size();i++){
			deal= deals.get(i);
			for(int j = 0; j<dealReports.size();j++){
			dealReport=dealReports.get(j);
			if(dealReport.getDealId() == deal.getDealId())
				map.put(deal, dealReport);
			
			}
		}
		
		mv.addObject("reportsMap", map);
		
		return mv;
	}
	
	
	@RequestMapping(method = RequestMethod.POST)
	public ModelAndView responseDashboard(HttpServletRequest request) {
		System.out.println("In the cont");
		List<DealMaster> deals = new ArrayList<DealMaster>();
		List<DealReport> dealReports = new ArrayList<DealReport>();
		Map<DealMaster , DealReport> map = new HashMap<DealMaster, DealReport>();
		DealDao dao = new DealDao();
		ModelAndView mv = new ModelAndView("dashboard.jsp");
		
		System.out.println(request.getParameter("selectedMonth"));
		
		deals = dao.getDashboardData(request.getParameter("selectedMonth"), request.getParameter("duLead"),request.getParameter("dgLead"),request.getParameter("location"));
		dealReports = dao.getDashboardReportData(deals);
		DealMaster deal = new DealMaster();
		DealReport dealReport = new DealReport();
		for(int i = 0; i<deals.size();i++){
			deal= deals.get(i);
			for(int j = 0; j<dealReports.size();j++){
			dealReport=dealReports.get(j);
			if(dealReport.getDealId() == deal.getDealId())
				map.put(deal, dealReport);
			
			}
		}
		
		mv.addObject("reportsMap", map);
		
		return mv;
	}
}

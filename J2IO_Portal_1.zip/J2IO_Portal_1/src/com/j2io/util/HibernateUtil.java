/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.j2io.util;

import javax.persistence.*;

import org.hibernate.*;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;

public class HibernateUtil {

	private static SessionFactory factory;
   

    public SessionFactory createFactory() throws HibernateException {
    		Configuration cfg = new AnnotationConfiguration();
			cfg.configure("hibernate.cfg.xml");
			factory = cfg.buildSessionFactory();
			return factory;
    }

}

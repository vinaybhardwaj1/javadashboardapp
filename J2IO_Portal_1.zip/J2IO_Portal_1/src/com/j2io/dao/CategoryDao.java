package com.j2io.dao;



import java.util.Iterator;
import java.util.List;


import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.j2io.entity.Category;
import com.j2io.util.HibernateUtil;


public class CategoryDao {
	
	HibernateUtil utilObj = new HibernateUtil();
	Session session = null;
	
	public CategoryDao(){
		
	}

	public List<Category> getCategoryByDeal(String dealName) {
		 session = utilObj.createFactory().openSession();
		 List cat = null;
        Transaction tx = null;
        try {
        	System.out.println("h1");
        	tx = session.beginTransaction();
           cat =  session.createSQLQuery("select * from category c " +
        	        "where c.deal_id = (select deal_id from deal_master where deal_name = :dealName)").addEntity(Category.class).setParameter("dealName", dealName)
        	        .list();
           System.out.println("h2");
        } catch (HibernateException e) {
            e.printStackTrace();
        } finally {
        	session.close();
        }
        return cat;
    }
	
	public List<Category> getAllCategories() {
		 session = utilObj.createFactory().openSession();
        List allCat = null;
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            allCat = session.createQuery("FROM Category").list();
            tx.commit();
        } catch (HibernateException e) {
        	if (tx!=null) tx.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
        return allCat;
    }
	
}

package com.j2io.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import com.j2io.entity.DealMaster;
import com.j2io.entity.DealReport;
import com.j2io.util.HibernateUtil;

public class DealDao {
	

	public DealMaster getDealData(String dealName,String month) {
		// TODO Auto-generated method stub
		HibernateUtil utilObj = new HibernateUtil();
        Session session = utilObj.createFactory().openSession();
        DealMaster deal = null;
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            deal = (DealMaster) session.createSQLQuery("select * from deal_master where deal_name = :dealName and month = :month").addEntity(DealMaster.class).setParameter("dealName", dealName).setParameter("month", month).uniqueResult();
            tx.commit();
        } catch (HibernateException e) {
        	if (tx!=null) tx.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
        return deal;
	}
	
	public List<String> getDealNames() {
		// TODO Auto-generated method stub
		HibernateUtil utilObj = new HibernateUtil();
        Session session = utilObj.createFactory().openSession();
        List<String> dealNames = new ArrayList<String>();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            dealNames = session.createSQLQuery("select distinct deal_name from deal_master").list();
            tx.commit();
        } catch (HibernateException e) {
        	if (tx!=null) tx.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
        return dealNames;
	}
	
	public void saveDeal(DealMaster deal){
		HibernateUtil utilObj = new HibernateUtil();
        Session session = utilObj.createFactory().openSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            session.update(deal);
            tx.commit();
        } catch (HibernateException e) {
        	if (tx!=null) tx.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
	}

	public void saveDealReport(DealReport dealReport) {
		// TODO Auto-generated method stub
		HibernateUtil utilObj = new HibernateUtil();
        Session session = utilObj.createFactory().openSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            session.saveOrUpdate(dealReport);
            tx.commit();
        } catch (HibernateException e) {
        	if (tx!=null) tx.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
	}
	
	public DealReport getDealReportByDeal(int dealId) {
		// TODO Auto-generated method stub
		HibernateUtil utilObj = new HibernateUtil();
        Session session = utilObj.createFactory().openSession();
        Transaction tx = null;
        DealReport dealReport = new DealReport(); 
        try {
            tx = session.beginTransaction();
            dealReport = (DealReport) session.createSQLQuery("select * from deal_report where deal_id = :dealId").addEntity(DealReport.class).setParameter("dealId", dealId).uniqueResult();
            tx.commit();
        } catch (HibernateException e) {
        	if (tx!=null) tx.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
        return dealReport;
		
	}

	public void deleteReportByDealId(int dealId) {
		// TODO Auto-generated method stub
		HibernateUtil utilObj = new HibernateUtil();
        Session session = utilObj.createFactory().openSession();
        Transaction tx = null;
        DealReport dealReport = new DealReport();
        try {
            tx = session.beginTransaction();
            dealReport = (DealReport) session.createSQLQuery("select * from deal_report where deal_id = :dealId").addEntity(DealReport.class).setParameter("dealId", dealId).uniqueResult();
            session.delete(dealReport);
            tx.commit();
        } catch (HibernateException e) {
        	if (tx!=null) tx.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
	}
	
	public List<DealMaster> getDashboardData(String month,String duLead,String dgLead,String location) {
		// TODO Auto-generated method stub
		HibernateUtil utilObj = new HibernateUtil();
        Session session = utilObj.createFactory().openSession();
        List<DealMaster> deals = new ArrayList<DealMaster>();
        Transaction tx = null;
       // String query = "select * from deal_master where month = :month";
        try {
            tx = session.beginTransaction();
            
            Criteria crit = session.createCriteria(DealMaster.class);
            crit.add(Restrictions.eq("month", month));
            
            if(!duLead.equals("All")){
            	crit.add(Restrictions.eq("duLead", duLead));
            }
            if(!dgLead.equals("All")){
            	crit.add(Restrictions.eq("dgLead", dgLead));
            }
            if(!location.equals("All"))
            {
            	crit.add(Restrictions.eq("location", location));
            }
            
            
           deals = crit.list();
            
            
            //deals =  session.createSQLQuery(query).addEntity(DealMaster.class).setParameter("duLead", duLead).setParameter("dgLead", dgLead).setParameter("location", location).setParameter("month", month).list();
            tx.commit();
        } catch (HibernateException e) {
        	if (tx!=null) tx.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
        return deals;
	}
	
	public List<DealReport> getDashboardReportData(List<DealMaster> deals) {
		// TODO Auto-generated method stub
		HibernateUtil utilObj = new HibernateUtil();
        Session session = utilObj.createFactory().openSession();
        List<DealReport> dealReports = new ArrayList<DealReport>();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            
            Criteria crit = session.createCriteria(DealReport.class);
            //crit.createAlias("dealReport","deal_id");
            List<Integer> dealIds = new ArrayList<Integer>();
            for (int i = 0; i < deals.size(); i++) {
            	dealIds.add(deals.get(i).getDealId());
    		}
            Integer[] x = (Integer[]) dealIds.toArray(new Integer[dealIds.size()]);
            //
            crit.add(Restrictions.in("dealId",x));
            dealReports = crit.list();
            tx.commit();
        } catch (HibernateException e) {
        	if (tx!=null) tx.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
        return dealReports;
	}

	public List<String> getDuLeadNames() {
		// TODO Auto-generated method stub
		HibernateUtil utilObj = new HibernateUtil();
        Session session = utilObj.createFactory().openSession();
        List<String> duLeadNames = new ArrayList<String>();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            duLeadNames = session.createSQLQuery("select distinct du_lead from deal_master").list();
            duLeadNames.remove(null);
            tx.commit();
        } catch (HibernateException e) {
        	if (tx!=null) tx.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
        return duLeadNames;
	}

	public List<String> getDgLeadNames() {
		// TODO Auto-generated method stub
		HibernateUtil utilObj = new HibernateUtil();
        Session session = utilObj.createFactory().openSession();
        List<String> dgLeadNames = new ArrayList<String>();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            dgLeadNames = session.createSQLQuery("select distinct dg_lead from deal_master").list();
            dgLeadNames.remove(null);
            tx.commit();
        } catch (HibernateException e) {
        	if (tx!=null) tx.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
        return dgLeadNames;
	}

	public List<String> getLocationNames() {
		// TODO Auto-generated method stub
		HibernateUtil utilObj = new HibernateUtil();
        Session session = utilObj.createFactory().openSession();
        List<String> locationNames = new ArrayList<String>();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            locationNames = session.createSQLQuery("select distinct location from deal_master").list();
            locationNames.remove(null);
            tx.commit();
        } catch (HibernateException e) {
        	if (tx!=null) tx.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
        return locationNames;
	}

//	public void addNewDeal(String newDealName,String newMonth,String newDgLead,String newDuLead,String newLocation) {
//		// TODO Auto-generated method stub
//		HibernateUtil utilObj = new HibernateUtil();
//        Session session = utilObj.createFactory().openSession();
//        DealMaster newDeal = getDealData("L'Oreal", "January");
//        newDeal.setDealId(dealId);
//        Transaction tx = null;
//        try {
//        	tx = session.beginTransaction();
//            session.saveOrUpdate(newDeal);
//            tx.commit();
//        } catch (HibernateException e) {
//        	if (tx!=null) tx.rollback();
//            e.printStackTrace();
//        } finally {
//            session.close();
//        }
//        //return locationNames;
//	}
}

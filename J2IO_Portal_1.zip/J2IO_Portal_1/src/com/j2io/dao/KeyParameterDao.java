package com.j2io.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.j2io.entity.Category;
import com.j2io.entity.KeyParameter;
import com.j2io.util.HibernateUtil;

public class KeyParameterDao {
	
	public List<KeyParameter> getAllKeyParameters() {
        HibernateUtil utilObj = new HibernateUtil();
        Session session = utilObj.createFactory().openSession();
        List allKeyParams = null;
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            allKeyParams = session.createQuery("FROM KeyParameter").list();
            tx.commit();
        } catch (HibernateException e) {
        	if (tx!=null) tx.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
        return allKeyParams;
    }

}

package com.j2io.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the deal_report database table.
 * 
 */
@Entity
@Table(name="deal_report")
@NamedQuery(name="DealReport.findAll", query="SELECT d FROM DealReport d")
public class DealReport implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="deal_report_id")
	private int dealReportId;

	@Temporal(TemporalType.DATE)
	private Date date;

	@Column(name="deal_id")
	private int dealId;

	@Column(name="f_score")
	private int founScore;

	@Column(name="i_score")
	private int innoScore;

	@Column(name="s_score")
	private int stabScore;

	@Column(name="t_score")
	private int tranScore;
	
	@Column(name="total_score")
	private int totalScore;

	public int getTotalScore() {
		return totalScore;
	}

	public void setTotalScore(int totalScore) {
		this.totalScore = totalScore;
	}

	public DealReport() {
	}

	public int getDealReportId() {
		return this.dealReportId;
	}

	public void setDealReportId(int dealReportId) {
		this.dealReportId = dealReportId;
	}

	public Date getDate() {
		return this.date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public int getDealId() {
		return this.dealId;
	}

	public void setDealId(int dealId) {
		this.dealId = dealId;
	}

	public int getFounScore() {
		return founScore;
	}

	public void setFounScore(int founScore) {
		this.founScore = founScore;
	}

	public int getInnoScore() {
		return innoScore;
	}

	public void setInnoScore(int innoScore) {
		this.innoScore = innoScore;
	}

	public int getStabScore() {
		return stabScore;
	}

	public void setStabScore(int stabScore) {
		this.stabScore = stabScore;
	}

	public int getTranScore() {
		return tranScore;
	}

	public void setTranScore(int tranScore) {
		this.tranScore = tranScore;
	}


}
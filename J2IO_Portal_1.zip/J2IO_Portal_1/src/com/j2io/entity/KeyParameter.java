package com.j2io.entity;


import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the key_parameters database table.
 * 
 */
@Entity
@Table(name="key_parameters")
@NamedQuery(name="KeyParameter.findAll", query="SELECT k FROM KeyParameter k")
public class KeyParameter implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="parameter_id")
	private int parameterId;

	@Column(name="foundation_attr")
	private String foundationAttr;

	@Column(name="foundation_score")
	private String foundationScore;

	@Column(name="innovation_attr")
	private String innovationAttr;

	@Column(name="innovation_score")
	private String innovationScore;

	@Column(name="parameter_name")
	private String parameterName;

	@Column(name="remarks")
	private String remarks;

	@Column(name="stabilization_attr")
	private String stabilizationAttr;

	@Column(name="stabilization_score")
	private String stabilizationScore;

	@Column(name="supporting_tools")
	private String supportingTools;

	@Column(name="transformation_attr")
	private String transformationAttr;

	@Column(name="transformation_score")
	private String transformationScore;

	//bi-directional many-to-one association to Category
	@ManyToOne
	@JoinColumn(name="category_id")
	private Category category;

	public KeyParameter() {
	}

	public int getParameterId() {
		return this.parameterId;
	}

	public void setParameterId(int parameterId) {
		this.parameterId = parameterId;
	}

	public String getFoundationAttr() {
		return this.foundationAttr;
	}

	public void setFoundationAttr(String foundationAttr) {
		this.foundationAttr = foundationAttr;
	}

	public String getFoundationScore() {
		return this.foundationScore;
	}

	public void setFoundationScore(String foundationScore) {
		this.foundationScore = foundationScore;
	}

	public String getInnovationAttr() {
		return this.innovationAttr;
	}

	public void setInnovationAttr(String innovationAttr) {
		this.innovationAttr = innovationAttr;
	}

	public String getInnovationScore() {
		return this.innovationScore;
	}

	public void setInnovationScore(String innovationScore) {
		this.innovationScore = innovationScore;
	}

	public String getParameterName() {
		return this.parameterName;
	}

	public void setParameterName(String parameterName) {
		this.parameterName = parameterName;
	}

	public String getRemarks() {
		return this.remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getStabilizationAttr() {
		return this.stabilizationAttr;
	}

	public void setStabilizationAttr(String stabilizationAttr) {
		this.stabilizationAttr = stabilizationAttr;
	}

	public String getStabilizationScore() {
		return this.stabilizationScore;
	}

	public void setStabilizationScore(String stabilizationScore) {
		this.stabilizationScore = stabilizationScore;
	}

	public String getSupportingTools() {
		return this.supportingTools;
	}

	public void setSupportingTools(String supportingTools) {
		this.supportingTools = supportingTools;
	}

	public String getTransformationAttr() {
		return this.transformationAttr;
	}

	public void setTransformationAttr(String transformationAttr) {
		this.transformationAttr = transformationAttr;
	}

	public String getTransformationScore() {
		return this.transformationScore;
	}

	public void setTransformationScore(String transformationScore) {
		this.transformationScore = transformationScore;
	}

	public Category getCategory() {
		return this.category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

}
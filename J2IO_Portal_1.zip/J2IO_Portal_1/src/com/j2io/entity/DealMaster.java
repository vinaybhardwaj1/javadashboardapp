package com.j2io.entity;

import java.io.Serializable;

import javax.persistence.*;
import javax.validation.constraints.Null;

import java.util.ArrayList;
import java.util.List;


import org.apache.commons.collections.FactoryUtils;
import org.apache.commons.collections.list.LazyList;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;
import org.springframework.util.AutoPopulatingList;
import org.springframework.util.AutoPopulatingList.ElementFactory;


/**
 * The persistent class for the deal_master database table.
 * 
 */
@Entity
@Table(name="deal_master")
@NamedQuery(name="DealMaster.findAll", query="SELECT d FROM DealMaster d")
public class DealMaster implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="deal_id")
	private int dealId;

	@Column(name="deal_name")
	private String dealName;

	//bi-directional many-to-one association to Category
	@LazyCollection(LazyCollectionOption.FALSE)
	@OneToMany(mappedBy="dealMaster", cascade = CascadeType.ALL)
	private List<Category> categories = LazyList.decorate(new ArrayList(), FactoryUtils.instantiateFactory(com.j2io.entity.Category.class));
	
	@Column(name="month")
	private String month;
	
	@Column(name="dg_lead")
	private String dgLead;

	@Column(name="du_lead")
	private String duLead;

	private String location;
	
	public String getDgLead() {
		return dgLead;
	}

	public void setDgLead(String dgLead) {
		this.dgLead = dgLead;
	}

	public String getDuLead() {
		return duLead;
	}

	public void setDuLead(String duLead) {
		this.duLead = duLead;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}
	
	public DealMaster() {
		
	}
	
	public DealMaster(int dealId,String dealName,List<Category> categories) {
		this.dealId = dealId;
		this.dealName = dealName;
		this.categories = categories;
	}

	public int getDealId() {
		return this.dealId;
	}

	public void setDealId(int dealId) {
		this.dealId = dealId;
	}

	public String getDealName() {
		return this.dealName;
	}

	public void setDealName(String dealName) {
		this.dealName = dealName;
	}

	public List<Category> getCategories() {
		return this.categories;
	}

	public void setCategories(List<Category> categories) {
		this.categories = categories;
	}

	public Category addCategory(Category category) {
		getCategories().add(category);
		category.setDealMaster(this);

		return category;
	}

	public Category removeCategory(Category category) {
		getCategories().remove(category);
		category.setDealMaster(null);

		return category;
	}

}
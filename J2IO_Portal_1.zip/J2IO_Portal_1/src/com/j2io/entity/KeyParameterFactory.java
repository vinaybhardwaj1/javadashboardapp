package com.j2io.entity;

import org.springframework.util.AutoPopulatingList;

public class KeyParameterFactory implements AutoPopulatingList.ElementFactory {
	
	public KeyParameterFactory( ) {

	  }
	
	 public Object createElement(int index) {
		    KeyParameter keyParameter = new KeyParameter();
		    return keyParameter;
		  }

}

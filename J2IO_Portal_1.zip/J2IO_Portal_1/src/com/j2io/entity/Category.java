package com.j2io.entity;

import java.io.Serializable;

import javax.persistence.*;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.FactoryUtils;
import org.apache.commons.collections.list.LazyList;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;
import org.springframework.util.AutoPopulatingList;


/**
 * The persistent class for the category database table.
 * 
 */
@Entity
@NamedQuery(name="Category.findAll", query="SELECT c FROM Category c")
public class Category implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="category_id")
	private int categoryId;

	@Column(name="category_name")
	private String categoryName;

	@Column(name="category_validation")
	private String categoryValidation;

	//bi-directional many-to-one association to DealMaster
	@ManyToOne
	@JoinColumn(name="deal_id")
	private DealMaster dealMaster;

	//bi-directional many-to-one association to KeyParameter
	@LazyCollection(LazyCollectionOption.FALSE)
	@OneToMany(mappedBy="category", cascade = CascadeType.ALL)
	private List<KeyParameter> keyParameters = LazyList.decorate(new ArrayList(), FactoryUtils.instantiateFactory(com.j2io.entity.KeyParameter.class));


	public Category() {
	}

	public int getCategoryId() {
		return this.categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public String getCategoryName() {
		return this.categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public String getCategoryValidation() {
		return this.categoryValidation;
	}

	public void setCategoryValidation(String categoryValidation) {
		this.categoryValidation = categoryValidation;
	}

	public DealMaster getDealMaster() {
		return this.dealMaster;
	}

	public void setDealMaster(DealMaster dealMaster) {
		this.dealMaster = dealMaster;
	}

	public List<KeyParameter> getKeyParameters() {
		return this.keyParameters;
	}

	public void setKeyParameters(List<KeyParameter> keyParameters) {
		this.keyParameters = keyParameters;
	}

	public KeyParameter addKeyParameter(KeyParameter keyParameter) {
		getKeyParameters().add(keyParameter);
		keyParameter.setCategory(this);

		return keyParameter;
	}

	public KeyParameter removeKeyParameter(KeyParameter keyParameter) {
		getKeyParameters().remove(keyParameter);
		keyParameter.setCategory(null);

		return keyParameter;
	}


}
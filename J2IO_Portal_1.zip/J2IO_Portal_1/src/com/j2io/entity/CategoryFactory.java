package com.j2io.entity;

import java.util.List;

import org.springframework.util.AutoPopulatingList;
import org.springframework.util.AutoPopulatingList.ElementFactory;

public class CategoryFactory implements AutoPopulatingList.ElementFactory{
	
	private List<KeyParameter> keyParameters = new AutoPopulatingList(new KeyParameterFactory());

	  public CategoryFactory() {
	     this.keyParameters = keyParameters;
	  }

	  public Object createElement(int index) {
	    Category category = new Category();
	    category.setKeyParameters(keyParameters);
	    return category;
	  }
}

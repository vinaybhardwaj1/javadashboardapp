package com.j2io.services;

import java.util.List;

import com.j2io.entity.DealMaster;
import com.j2io.entity.DealReport;
import com.j2io.entity.KeyParameter;

public interface DealFacade {

	DealMaster getDealByNameAndDate(String dealName,String month);
	void saveDealService(DealMaster deal);
	DealReport calculateDealService(DealMaster deal);
	void saveDealReport(DealReport dealReport);
}

package com.j2io.services;

import java.util.ArrayList;
import java.util.List;

import com.j2io.dao.DealDao;
import com.j2io.entity.Category;
import com.j2io.entity.DealMaster;
import com.j2io.entity.DealReport;
import com.j2io.entity.KeyParameter;


public class DealServiceImpl implements DealFacade{

	@Override
	public DealMaster getDealByNameAndDate(String dealName,String month) {
		// TODO Auto-generated method stub
		DealDao dao = new DealDao();
		DealMaster deal = dao.getDealData(dealName,month);
		return deal;
	}

	@Override
	public void saveDealService(DealMaster deal) {
		// TODO Auto-generated method stub
		DealDao dao = new DealDao();
		dao.saveDeal(deal);
	}
	
	public DealReport calculateDealService(DealMaster deal) {
		// TODO Auto-generated method stub
		DealDao dao = new DealDao();
		DealReport dealReport = new DealReport();
		int fscore,tscore,iscore,sscore,totalscore;
		int totalcount[] = new int[4];
		List<Category> categories = deal.getCategories();
		List<KeyParameter> keyParameters = new ArrayList<KeyParameter>();
		fscore=tscore=iscore=sscore=totalscore=0;
		for(int i=0;i<totalcount.length;i++)
			totalcount[i] = 0;
		for(int i=0;i<categories.size();i++)
		{
			keyParameters = categories.get(i).getKeyParameters();
			for(int j=0;j<keyParameters.size();j++)
			{ 
				if(Integer.parseInt(keyParameters.get(j).getFoundationScore()) != 2){
					fscore = fscore + Integer.parseInt(keyParameters.get(j).getFoundationScore());
					totalcount[0]++;
				}
				if(Integer.parseInt(keyParameters.get(j).getTransformationScore()) != 2){
					tscore = tscore + Integer.parseInt(keyParameters.get(j).getTransformationScore());
					totalcount[1]++;
				}
				if(Integer.parseInt(keyParameters.get(j).getStabilizationScore()) != 2){
					sscore = sscore + Integer.parseInt(keyParameters.get(j).getStabilizationScore());
					totalcount[2]++;
				}
				if(Integer.parseInt(keyParameters.get(j).getInnovationScore()) != 2){
					iscore = iscore + Integer.parseInt(keyParameters.get(j).getInnovationScore());
					totalcount[3]++;
				}
			}
				
		}
		if(totalcount[0] == 0 || totalcount[1] == 0 || totalcount[2] == 0 || totalcount[3] == 0){
			dealReport.setFounScore(999);
			return dealReport;
		}
		fscore = fscore*100/totalcount[0];
		tscore = tscore*100/totalcount[1];
		sscore = sscore*100/totalcount[2];
		iscore = iscore*100/totalcount[3];
		totalscore = (fscore + tscore + sscore + iscore)/4;
		dealReport.setDealId(deal.getDealId());
		dealReport.setFounScore(fscore);
		dealReport.setTranScore(tscore);
		dealReport.setStabScore(sscore);
		dealReport.setInnoScore(iscore);
		dealReport.setTotalScore(totalscore);
		return dealReport;
	}
	
	@Override
	public void saveDealReport(DealReport dealReport) {
		// TODO Auto-generated method stub
		DealDao dao = new DealDao();
		dao.saveDealReport(dealReport);
	}

	public DealReport getDealReportByDealId(int dealId) {
		// TODO Auto-generated method stub
		DealDao dao = new DealDao();
		DealReport dealReport = new DealReport();
		dealReport = dao.getDealReportByDeal(dealId);
		return dealReport;
	}

	public void deleteDealReportByDealId(int dealId) {
		// TODO Auto-generated method stub
		DealDao dao = new DealDao();
		dao.deleteReportByDealId(dealId);
	}
	
	public List<String> getAllDealNames() {
		// TODO Auto-generated method stub
		DealDao dao = new DealDao();
		List<String> dealNames = new ArrayList<String>();
		dealNames = dao.getDealNames();
		return dealNames;
	}

	public List<String> getAllDuLeadNames() {
		// TODO Auto-generated method stub
		DealDao dao = new DealDao();
		List<String> duLeadList = new ArrayList<String>();
		duLeadList = dao.getDuLeadNames();
		return duLeadList;
	}

	public List<String> getAllLocations() {
		// TODO Auto-generated method stub
		DealDao dao = new DealDao();
		List<String> dgLeadList = new ArrayList<String>();
		dgLeadList = dao.getLocationNames();
		return dgLeadList;
	}

	public List<String> getAllDgLeadNames() {
		// TODO Auto-generated method stub
		DealDao dao = new DealDao();
		List<String> locations = new ArrayList<String>();
		locations = dao.getDgLeadNames();
		return locations;
	}

}

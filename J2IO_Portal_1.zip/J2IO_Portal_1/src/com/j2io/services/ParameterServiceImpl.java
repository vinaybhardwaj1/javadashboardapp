package com.j2io.services;

import java.util.List;

import com.j2io.dao.KeyParameterDao;
import com.j2io.entity.DealMaster;
import com.j2io.entity.KeyParameter;

public class ParameterServiceImpl implements ParameterFacade{

	@Override
	public List<KeyParameter> getAllKeyParams() {
		// TODO Auto-generated method stub
		KeyParameterDao dao = new KeyParameterDao();
		List<KeyParameter> keyParamList = dao.getAllKeyParameters();
		return keyParamList;
	}



}

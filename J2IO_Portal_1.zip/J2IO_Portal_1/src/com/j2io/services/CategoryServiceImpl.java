package com.j2io.services;

import java.util.ArrayList;
import java.util.List;

import com.j2io.dao.CategoryDao;
import com.j2io.entity.Category;

public class CategoryServiceImpl implements CategoryFacade{

	@Override
	public List<Category> getAllCategories() {
		// TODO Auto-generated method stub
		CategoryDao dao = new CategoryDao();
		List<Category> categoryList = new ArrayList<Category>();
		categoryList = dao.getAllCategories();
		return categoryList;
	}

	@Override
	public List<Category> getAllCategoriesByDeal(String dealName) {
		// TODO Auto-generated method stub
		CategoryDao dao = new CategoryDao();
		List<Category> categoryList = new ArrayList<Category>();
		categoryList = dao.getCategoryByDeal(dealName);
		return categoryList;
	}

}

package com.j2io.services;

import java.util.List;

import com.j2io.entity.Category;

public interface CategoryFacade {

	List<Category> getAllCategories();

	List<Category> getAllCategoriesByDeal(String dealName);

	

}

package com.j2io.services;

import java.util.List;

import com.j2io.entity.DealMaster;
import com.j2io.entity.KeyParameter;

public interface ParameterFacade {

	List<KeyParameter> getAllKeyParams();

}


//$(document).ready(function(){
$('.stopGapCondition').each(function() {
    var $this = $(this);
    var value = $this.find('option:selected').text();
    
    if(value == "Yes") {
    	$this.removeClass('red');
    	$this.removeClass('notApplicable');
        $this.addClass('green');
    } else if(value == "NA") {
    	$this.removeClass('red');
    	$this.removeClass('green');
        $this.addClass('notApplicable');
    } else if(value == "No"){
    	$this.removeClass('green');
    	$this.removeClass('notApplicable');
        $this.addClass('red');
    }
});


$('td.stopGapCondition').change(function() {

    var $this = $(this);
    var value = $(this).find('option:selected').text();
    
    
    console.log(value);
    if(value == "Yes") {
    	$this.removeClass('red');
    	$this.removeClass('notApplicable');
        $this.addClass('green');
    } else if(value == "NA") {
    	$this.removeClass('red');
    	$this.removeClass('green');
        $this.addClass('notApplicable');
    } else if(value == "No"){
    	$this.removeClass('green');
    	$this.removeClass('notApplicable');
        $this.addClass('red');
    }
    
});

